$("#entrada").on("blur", function(event){
	var res = $(this).val().split("").reverse().join("");
	$("#resultado").val(res).select();
})